#! /usr/bin/env python
import rospy

from std_msgs.msg import UInt8

if __name__ == "__main__":
    rospy.init_node('counter_node')
    pub = rospy.Publisher('counter_topic', UInt8, queue_size=10)


    rate = rospy.Rate(10)
    count = UInt8()
    count.data = 0


    while not rospy.is_shutdown():
        pub.publish(count)
        
        if count.data  == 255:
            count.data = 0;
        else:
            count.data += 1;

        rate.sleep()