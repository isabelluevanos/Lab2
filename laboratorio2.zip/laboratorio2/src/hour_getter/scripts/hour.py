#! /usr/bin/env python
import rospy


import datetime
from std_msgs.msg import String


if __name__ == "__main__":
    rospy.init_node('hour_node')
    pub = rospy.Publisher('hour_topic', String, queue_size=10)


    rate = rospy.Rate(2)

    while not rospy.is_shutdown():

        date = datetime.datetime.now()
        msg1= "{ano},{mes},{dia},{hora},{minuto},{segundo}".format(dia=date.day, mes=date.month, ano=date.year, hora=date.hour, minuto=date.minute, segundo=date.second)
        pub.publish(msg1)
        rate.sleep()
